(function(){

			// Menu settings
			$('.navPanelToggle, .close, #login, #reg').on('click', function(){
				$('#navPanel').toggleClass('visible');
			});


})(jQuery)