<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['category'] = 'category';
$route['category/(:any)'] = 'category/view/$1';